from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
db = SQLAlchemy(app)


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    roll_number = db.Column(db.String(50), unique=True)
    name = db.Column(db.String(255))
    dob = db.Column(db.Date)

    def __init__(self, roll_number, name, dob):
        self.roll_number = roll_number
        self.name = name
        self.dob = dob


class Mark(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    student = db.relationship('Student', backref=db.backref('marks', lazy=True))
    mark = db.Column(db.Integer)

    def __init__(self, student, mark):
        self.student = student
        self.mark = mark


@app.route('/api/students/', methods=['GET'])
def get_all_students():
    students = Student.query.all()
    result = []
    for student in students:
        result.append({
            'id': student.id,
            'roll_number': student.roll_number,
            'name': student.name,
            'dob': student.dob.strftime('%Y-%m-%d')
        })
    return jsonify(result)


@app.route('/api/student/add/', methods=['POST'])
def add_student():
    roll_number = request.json['roll_number']
    name = request.json['name']
    dob = request.json['dob']
    student = Student(roll_number=roll_number, name=name, dob=dob)
    db.session.add(student)
    db.session.commit()
    return jsonify({'message': 'Student added successfully'})


@app.route('/api/student/<int:pk>/', methods=['GET'])
def get_student(pk):
    student = Student.query.get(pk)
    if student is None:
        return jsonify({'message': 'Student not found'})
    return jsonify({
        'id': student.id,
        'roll_number': student.roll_number,
        'name': student.name,
        'dob': student.dob.strftime('%Y-%m-%d')
    })


@app.route('/api/student/<int:pk>/add-mark/', methods=['POST'])
def add_mark(pk):
    student = Student.query.get(pk)
    if student is None:
        return jsonify({'message': 'Student not found'})
    mark = request.json['mark']
    mark_entry = Mark(student=student, mark=mark)
    db.session.add(mark_entry)
    db.session.commit()
    return jsonify({'message': 'Mark added successfully'})


@app.route('/api/student/<int:pk>/mark/', methods=['GET'])
def get_marks(pk):
    student = Student.query.get(pk)
    if student is None:
        return jsonify({'message': 'Student not found'})
    marks = Mark.query.filter_by(student=student).all()
    result = []
    for mark in marks:
        result.append({
            'id': mark.id,
            'student_id': mark.student_id,
            'mark': mark.mark
        })
    return jsonify(result)


@app.route('/api/student/results/', methods=['GET'])
def get_results():
    total_students = Student.query.count()
    f_grade_count = Mark.query.filter(Mark.mark < 50).count()
    pass_percentage = ((total_students - f_grade_count) / total_students) * 100

    grades = {        'S': {'min': 91, 'max': 100},
        'A': {'min': 81, 'max': 90},
        'B': {'min': 71, 'max': 80},
        'C': {'min': 61, 'max': 70},
        'D': {'min': 51, 'max': 60},
        'E': {'min': 50, 'max': 55},
        'F': {'max': 49}
    }

    grade_results = {}
    for grade, grade_range in grades.items():
        if grade == 'F':
            count = f_grade_count
        else:
            count = Mark.query.filter(Mark.mark >= grade_range['min'], Mark.mark <= grade_range['max']).count()
        grade_results[grade] = count

    result = {
        'S grade': grade_results['S'],
        'A grade': grade_results['A'],
        'B grade': grade_results['B'],
        'C grade': grade_results['C'],
        'D grade': grade_results['D'],
        'E grade': grade_results['E'],
        'F grade': grade_results['F'],
        'Pass Percentage': pass_percentage
    }

    return jsonify(result)

if __name__ == '__main__':
    #db.create_all()
    app.run(debug=True)


